package DAO;

import POJO.Merchantuser;

public interface MerchantuserMapper {
    int insert(Merchantuser record);

    int insertSelective(Merchantuser record);
}