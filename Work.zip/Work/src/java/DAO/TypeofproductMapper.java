package DAO;

import POJO.Typeofproduct;

public interface TypeofproductMapper {
    int insert(Typeofproduct record);

    int insertSelective(Typeofproduct record);
}