package DAO;

import POJO.Transportation;

public interface TransportationMapper {
    int insert(Transportation record);

    int insertSelective(Transportation record);
}