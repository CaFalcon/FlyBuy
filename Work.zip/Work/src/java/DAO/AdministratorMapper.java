package DAO;

import POJO.Administrator;

public interface AdministratorMapper {
    int insert(Administrator record);

    int insertSelective(Administrator record);
}