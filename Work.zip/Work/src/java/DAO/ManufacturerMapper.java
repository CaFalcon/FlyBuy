package DAO;

import POJO.Manufacturer;

public interface ManufacturerMapper {
    int insert(Manufacturer record);

    int insertSelective(Manufacturer record);
}