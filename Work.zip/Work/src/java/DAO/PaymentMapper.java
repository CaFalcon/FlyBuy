package DAO;

import POJO.Payment;

public interface PaymentMapper {
    int insert(Payment record);

    int insertSelective(Payment record);
}