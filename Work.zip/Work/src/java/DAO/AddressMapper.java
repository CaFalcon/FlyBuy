package DAO;

import POJO.Address;

public interface AddressMapper {
    int insert(Address record);

    int insertSelective(Address record);
}