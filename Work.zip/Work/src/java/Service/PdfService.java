package Service;

import DAO.OrderMapper;
import DAO.PersonalinformationMapper;
import DAO.ProductMapper;
import DAO.UserMapper;
import POJO.Order;
import POJO.Personalinformation;
import POJO.Product;
import POJO.User;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPHeaderCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class PdfService {

    List<Order> orderList = null;
    List<User> userList = null;
    List<Personalinformation> personalinformationList = null;
    List<Product> productList = null;

    public PdfService() {
        readDb();
    }

    private void readDb() {
        InputStream is = null;
        try {
            is = Resources.getResourceAsStream("mybatis-config.xml");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //初始化mybatis，创建SqlSessionFactory类实例
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(is);
        //创建Session实例
        SqlSession session = sqlSessionFactory.openSession();

        OrderMapper orderMapper = session.getMapper(OrderMapper.class);
        orderList = orderMapper.getOrders();

        UserMapper userMapper = session.getMapper(UserMapper.class);
        userList = userMapper.getUsers();

        PersonalinformationMapper personalinformationMapper = session.getMapper(PersonalinformationMapper.class);
        personalinformationList = personalinformationMapper.getPersonalInformations();

        ProductMapper productMapper = session.getMapper(ProductMapper.class);
        productList = productMapper.getProducts();

        //关闭Session
        session.close();
    }


    public void writePdfTable(String fileName) throws Exception {
        List<String> userNameList = new ArrayList<>();
        List<String> firstNameList = new ArrayList<>();
        List<String> lastNameList = new ArrayList<>();
        List<String> productNameList = new ArrayList<>();

        for (Order order : orderList) {
            for (User user : userList) {
                if (order.getOrdernumber().equals(user.getOrdernumber())) {
                    for (Personalinformation personalinformation : personalinformationList) {
                        if (personalinformation.getPersonalid().equals(user.getPersonalid())) {
                            userNameList.add(user.getUsername());
                            firstNameList.add(personalinformation.getFirstname());
                            lastNameList.add(personalinformation.getLastname());
                            break;
                        }
                    }
                    break;
                }
            }
            for (Product product : productList) {
                if (product.getProductid().equals(order.getProductid())) {
                    productNameList.add(product.getProductname());
                    break;
                }
            }
        }

        Document document = null;
        PdfWriter writer = null;
        try {
            String fullPath = fileName + ".pdf";
            document = new Document();
            document.setPageSize(PageSize.A4);
            writer = PdfWriter.getInstance(document, new FileOutputStream(fullPath));
            document.open();

            // 中文字体,解决中文不能显示问题
            BaseFont bfChinese = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
            // 正常字体
            Font font = new Font(bfChinese);
            // 正常加粗字体
            Font fontBold = new Font(bfChinese, 12, Font.BOLD);
            // 加粗大字体
            Font fontBigBold = new Font(bfChinese, 20, Font.BOLD);

            String title = "ShopInformation";
            PdfPTable table1 = new PdfPTable(4);
            table1.setTotalWidth(PageSize.A4.getWidth() - 40);
            table1.setLockedWidth(true);
            PdfPHeaderCell header = new PdfPHeaderCell();
            header.addElement(new Paragraph(title, fontBigBold));
            header.setColspan(4);
            table1.addCell(header);
            table1.addCell(new Paragraph("username", font));
            table1.addCell(new Paragraph("firstname", font));
            table1.addCell(new Paragraph("lastname", font));
            table1.addCell(new Paragraph("productname", font));

            for (int i = 0; i < userNameList.size(); i++) {
                table1.addCell(new Paragraph(userNameList.get(i), font));
                table1.addCell(new Paragraph(firstNameList.get(i), font));
                table1.addCell(new Paragraph(lastNameList.get(i), font));
                table1.addCell(new Paragraph(productNameList.get(i), font));
            }

            document.add(table1);

            // 关闭文档，才能输出
            document.close();
            writer.close();
        } catch (Exception e) {
            throw e;
        } finally {
            if (document != null) {
                document.close();
            }
            if (writer != null) {
                writer.close();
            }
        }
    }

}
