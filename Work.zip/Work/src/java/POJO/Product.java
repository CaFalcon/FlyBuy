package POJO;

public class Product {
    private String productid;

    private String productname;

    private String typeofproduct;

    private String productowner;

    private Integer inventoryquantity;

    private String description;

    private String currency;

    private Long price;

    private String manufacturer;

    public String getProductid() {
        return productid;
    }

    public void setProductid(String productid) {
        this.productid = productid == null ? null : productid.trim();
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname == null ? null : productname.trim();
    }

    public String getTypeofproduct() {
        return typeofproduct;
    }

    public void setTypeofproduct(String typeofproduct) {
        this.typeofproduct = typeofproduct == null ? null : typeofproduct.trim();
    }

    public String getProductowner() {
        return productowner;
    }

    public void setProductowner(String productowner) {
        this.productowner = productowner == null ? null : productowner.trim();
    }

    public Integer getInventoryquantity() {
        return inventoryquantity;
    }

    public void setInventoryquantity(Integer inventoryquantity) {
        this.inventoryquantity = inventoryquantity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer == null ? null : manufacturer.trim();
    }

    @Override
    public String toString() {
        return "Product{" +
                "productid='" + productid + '\'' +
                ", productname='" + productname + '\'' +
                ", typeofproduct='" + typeofproduct + '\'' +
                ", productowner='" + productowner + '\'' +
                ", inventoryquantity=" + inventoryquantity +
                ", description='" + description + '\'' +
                ", currency='" + currency + '\'' +
                ", price=" + price +
                ", manufacturer='" + manufacturer + '\'' +
                '}';
    }
}