package POJO;

public class Payment {
    private Integer paymentid;

    private String nameoncard;

    private String creditcardnumber;

    private Integer expyear;

    private String expmonth;

    private Integer cvv;

    public Integer getPaymentid() {
        return paymentid;
    }

    public void setPaymentid(Integer paymentid) {
        this.paymentid = paymentid;
    }

    public String getNameoncard() {
        return nameoncard;
    }

    public void setNameoncard(String nameoncard) {
        this.nameoncard = nameoncard == null ? null : nameoncard.trim();
    }

    public String getCreditcardnumber() {
        return creditcardnumber;
    }

    public void setCreditcardnumber(String creditcardnumber) {
        this.creditcardnumber = creditcardnumber == null ? null : creditcardnumber.trim();
    }

    public Integer getExpyear() {
        return expyear;
    }

    public void setExpyear(Integer expyear) {
        this.expyear = expyear;
    }

    public String getExpmonth() {
        return expmonth;
    }

    public void setExpmonth(String expmonth) {
        this.expmonth = expmonth == null ? null : expmonth.trim();
    }

    public Integer getCvv() {
        return cvv;
    }

    public void setCvv(Integer cvv) {
        this.cvv = cvv;
    }
}