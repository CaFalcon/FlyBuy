package POJO;

import java.util.Date;

public class Order {
    private Integer ordernumber;

    private String productid;

    private String productname;

    private Integer quantity;

    private String state;

    private String tracking;

    private String seller;

    private Date createdat;

    public Integer getOrdernumber() {
        return ordernumber;
    }

    public void setOrdernumber(Integer ordernumber) {
        this.ordernumber = ordernumber;
    }

    public String getProductid() {
        return productid;
    }

    public void setProductid(String productid) {
        this.productid = productid == null ? null : productid.trim();
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname == null ? null : productname.trim();
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getTracking() {
        return tracking;
    }

    public void setTracking(String tracking) {
        this.tracking = tracking == null ? null : tracking.trim();
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller == null ? null : seller.trim();
    }

    public Date getCreatedat() {
        return createdat;
    }

    public void setCreatedat(Date createdat) {
        this.createdat = createdat;
    }

    @Override
    public String toString() {
        return "Order{" +
                "ordernumber=" + ordernumber +
                ", productid='" + productid + '\'' +
                ", productname='" + productname + '\'' +
                ", quantity=" + quantity +
                ", state='" + state + '\'' +
                ", tracking='" + tracking + '\'' +
                ", seller='" + seller + '\'' +
                ", createdat=" + createdat +
                '}';
    }
}