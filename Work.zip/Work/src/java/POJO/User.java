package POJO;

import java.util.Date;

public class User {
    private String id;

    private Integer personalid;

    private Integer paymentid;

    private Integer addressid;

    private String username;

    private String password;

    private String administratorid;

    private Integer ordernumber;

    private Date createdat;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Integer getPersonalid() {
        return personalid;
    }

    public void setPersonalid(Integer personalid) {
        this.personalid = personalid;
    }

    public Integer getPaymentid() {
        return paymentid;
    }

    public void setPaymentid(Integer paymentid) {
        this.paymentid = paymentid;
    }

    public Integer getAddressid() {
        return addressid;
    }

    public void setAddressid(Integer addressid) {
        this.addressid = addressid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getAdministratorid() {
        return administratorid;
    }

    public void setAdministratorid(String administratorid) {
        this.administratorid = administratorid == null ? null : administratorid.trim();
    }

    public Integer getOrdernumber() {
        return ordernumber;
    }

    public void setOrdernumber(Integer ordernumber) {
        this.ordernumber = ordernumber;
    }

    public Date getCreatedat() {
        return createdat;
    }

    public void setCreatedat(Date createdat) {
        this.createdat = createdat;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", personalid=" + personalid +
                ", paymentid=" + paymentid +
                ", addressid=" + addressid +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", administratorid='" + administratorid + '\'' +
                ", ordernumber=" + ordernumber +
                ", createdat=" + createdat +
                '}';
    }
}