package POJO;

import java.util.Date;

public class Transportation {
    private String trackingid;

    private String startingplace;

    private String destination;

    private Date createdat;

    public String getTrackingid() {
        return trackingid;
    }

    public void setTrackingid(String trackingid) {
        this.trackingid = trackingid == null ? null : trackingid.trim();
    }

    public String getStartingplace() {
        return startingplace;
    }

    public void setStartingplace(String startingplace) {
        this.startingplace = startingplace == null ? null : startingplace.trim();
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination == null ? null : destination.trim();
    }

    public Date getCreatedat() {
        return createdat;
    }

    public void setCreatedat(Date createdat) {
        this.createdat = createdat;
    }
}