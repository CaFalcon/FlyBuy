import Service.PdfService;

public class Main {

    public static void main(String[] args) throws Exception {
        new PdfService().writePdfTable("WebShop");
    }
}
